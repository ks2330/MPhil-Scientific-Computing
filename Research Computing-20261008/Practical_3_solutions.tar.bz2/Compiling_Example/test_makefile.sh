#!/bin/bash

rm -f example1 example2 *.o

make example1

if [[ ! -f example1 ]]; then
    echo "Failed to compile example1"
    exit 1
fi

make example2

if [[ ! -f example2 ]]; then
    echo "Failed to compile example2"
    exit 1
fi

make clean

if [[ -f example1 || -f example2 || -f example1.o || -f example2.o || -f library.o ]]; then
    echo "Failed to clean up completely."
    exit 1
fi

make all

if [[ ! -f example1 || ! -f example2 ]]; then
    echo "Failed to compile example1 and example2"
    exit 1
fi

touch library.C

commands=`make all |& wc -l`
if [[ "$commands" -ne 3 ]]; then
    echo "Ran $commands commands after changing library.C. Should be 3 commands"
    exit 1
fi

touch example1.C

commands=`make all |& wc -l`
if [[ "$commands" -ne 2 ]]; then
    echo "Ran $commands commands after changing example1.C. Should be 2 commands"
    exit 1
fi

touch example1.C

commands=`make all |& wc -l`
if [[ "$commands" -ne 2 ]]; then
    echo "Ran $commands commands after changing example2.C. Should be 2 commands"
    exit 1
fi

touch library.H

commands=`make all |& wc -l`
if [[ "$commands" -ne 5 ]]; then
    echo "Ran $commands commands after changing library.H. Should be 5 commands"
    exit 1
fi

echo "Everything OK!"
exit 0
