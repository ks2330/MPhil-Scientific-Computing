#include<iostream>

int main(void)
{
  std::string name;
  std::cout << "What is your name?" << std::endl;
  std::cin >> name;
  int n;
  std::cout << "What is your favourite number?" << std::endl;
  std::cin >> n;

  std::cout << "Hello " << name << " you like " << n << std::endl;
  return 0;
}
