#!/bin/bash

if [[ $# -ne 1 ]]; then
    echo "Please specify a single suffix as an argument to this script"
    exit 1
fi

suffix=$1

files=$(find . -name "*.$suffix")

# wc expects multiple words, so disable shellcheck suggestion.
# shellcheck disable=SC2086
numFiles=$(echo $files | wc -w)

if [[ $numFiles -ne 1 ]]; then
    echo "There are $numFiles files with suffix .$suffix"
else
    echo "There is $numFiles file with suffix .$suffix"    
fi
if [[ $numFiles -eq 0 ]]; then
    exit 0
fi

# tar requires multiple words from $files expansion
# so disable shellcheck suggestion.
# shellcheck disable=SC2086
tar -cjf "Files_${suffix}.tar.bz2" $files
